//
//  XCGLogger.h
//  XCGLogger: https://github.com/DaveWoodCom/XCGLogger
//
//  Created by Dave Wood on 2014-06-06.
//  Copyright (c) 2014 Dave Wood, Cerebral Gardens.
//  Some rights reserved: https://github.com/DaveWoodCom/XCGLogger/blob/master/LICENSE.txt
//

#import <Foundation/Foundation.h>

//! Project version number for XCGLogger.
FOUNDATION_EXPORT double XCGLoggerVersionNumber;

//! Project version string for XCGLogger.
FOUNDATION_EXPORT const unsigned char XCGLoggerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <XCGLogger/PublicHeader.h>


